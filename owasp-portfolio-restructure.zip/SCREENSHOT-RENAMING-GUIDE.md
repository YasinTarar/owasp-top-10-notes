# Screenshot Renaming Guide

This file documents what each original screenshot should be renamed to when reorganising the repository.
Delete this file once you've completed the renaming.

---

## SQL Injection — move to: `A03-Injection/sql-injection/screenshots/`

| Original filename | Rename to |
|---|---|
| `sqli-login-page.png` | `01-login-page.png` |
| `sql-injection-hidden-data-before.png` | `02-hidden-data-before-injection.png` |
| `sqli-admin-login-success.png` | `03-admin-login-bypass.png` |

---

## Reflected XSS — move to: `A03-Injection/reflected-xss/screenshots/`

| Original filename | Rename to |
|---|---|
| `xss-alert-payload.png` | `01-alert-payload.png` |
| `xss-popup-result.png` | `02-popup-result.png` |

---

## Stored XSS — move to: `A03-Injection/stored-xss/screenshots/`

| Original filename | Rename to |
|---|---|
| `stored-xss-comment-payload.png` | `01-comment-payload.png` |
| `stored-xss-popup-alert.png` | `02-popup-alert.png` |
| `stored-xss-lab-solved.png` | `03-lab-solved.png` |

---

## DOM-Based XSS — move to: `A03-Injection/dom-xss/screenshots/`

| Original filename | Rename to |
|---|---|
| `dom-xss-inspect-code.png` | `01-inspect-vulnerable-code.png` |
| `dom-xss-payload-url.png` | `02-payload-in-url.png` |

---

## Unidentified screenshots

| Original filename | Notes |
|---|---|
| `Screenshot 2026-05-22 010600.png` | Check what this shows — rename and move to the correct subfolder, or delete if it's a duplicate |

---

## Git commands to run

Once you've reorganised the files in your local repo, stage everything and commit:

```bash
git add .
git commit -m "restructure: reorganise into OWASP category folders with professional naming"
git push origin main
```
